/*
Equipo: 15
Integrantes: 
A00828424     Javier Garza Pedraza 
A01570150     Andres Piñones Besnier
*/



#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>
#include <cstdlib>
#include <fstream>


using namespace std;

//complejidad O(1)
//Esta funcion la usamos para pasar del string de mes y dia a una sola key que usamos al momento de ordenar el vector. 
int keyDeFecha(string mes, int dia){
  int key;
  if (mes=="Jan"){key=1;}
  if (mes=="Feb"){key=2;}
  if (mes=="Mar"){key=3;}
  if (mes=="Apr"){key=4;}
  if (mes=="May"){key=5;}
  if (mes=="Jun"){key=6;}
  if (mes=="Jul"){key=7;}
  if (mes=="Aug"){key=8;}
  if (mes=="Sep"){key=9;}
  if (mes=="Oct"){key=10;}
  if (mes=="Nov"){key=11;}
  if (mes=="Dec"){key=12;}

  return (key*100)+(dia);
}

struct datos{
  int key;
  string datos;

};

//Complejidad O(1)
//Esta funcion es necesaria para la funcion de Sort, en ella señalamos que son las Key lo que queremos que se ordene
bool comparar(const datos &a, const datos &b){
    return a.key < b.key;
}


int main ()
{

  vector <datos> lista {};

  //abrimos el archivo y despues lo recorremos con el while hasta que ya no queden datos en el 
  ifstream archivo("bitacora1.txt");

    string mes;
    string dia;
    string hora;
    string ip;
    string error;
    string todo;
    int intNum;

    //complejidad O(n)
    //Recorre todo el archivo y damos 2 variables, una Key que se obtiene con la funcion KeyDeFecha y una de datos que contiene toda la linea como un string
    while(archivo.good()){
      getline(archivo, mes, ' ');
      getline(archivo, dia, ' ');
      getline(archivo, hora, ' ');
      getline(archivo, ip, ' ');
      getline(archivo, error, '\n');

      todo=mes+" "+dia+" "+hora+" "+ip+" "+error;
      intNum=keyDeFecha(mes, stoi(dia));
      datos dato;
      dato.key=intNum;
      dato.datos=todo;
      
      lista.push_back(dato);
      
      
    }
  archivo.close();
  
  //ordenar el vector 
  //complejidad O(N*log2(N))
  sort(lista.begin(), lista.end(),comparar);

  

  //abrir archivo de resultados
  
  int ini, fin, diaa;
  string seguir;

  do{
    //pide al usuario los datos para realizar la busqueda y los transforma en la key
    cout<<"Fecha de inicio (Mes dia): "<<endl;
    cin>>mes>>diaa;
    ini=keyDeFecha(mes, diaa);
    cout<<"Fecha de fin (Mes dia):"<<endl;
    cin>>mes>>diaa;
    fin=keyDeFecha(mes, diaa);
    
    //filtra y muestra los datos pedidos
    //complejidad     O(n)
    for(int c=0; c<lista.size();c++){
        if (lista[c].key>=ini && lista[c].key<=fin){
          cout<<lista[c].datos<<endl;
        }
      
      }
    cout<<"quiere realizar otra busqueda?: (no) "<<endl;
    cin>>seguir;
  }while((seguir != "No")&&(seguir != "no"));

  
  ofstream myfile;

  
  //Aqui pedimos y guardamos el archivo con los datos ya ordenados 
  string nombreArchivo;
  cout<<"digite el nombre del archivo: "<<endl;
  cin>>nombreArchivo;

  myfile.open (nombreArchivo.c_str(), ios::out);

  //complejidad O(n)
  for(int i=0; i<lista.size(); i++){
    myfile<<lista[i].datos<<endl;
  }
  //cerrar archivo de resultados
  myfile.close();
  
  return 0;
}