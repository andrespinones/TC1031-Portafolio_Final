#include <iostream>
#include <queue>
#include <stack>
#include <fstream>

using namespace std;

#include "BST.h"


//convierte el ip a una key que nos permite hacer las comparaciones
long ipToKey(string ip){
	int idx = 0;
	long  dato = 0;
	for(int i=0; i<ip.length(); i++){
		if (ip[idx]!= '.' ){

			dato = dato*10+(ip[idx]-'0');
		}
		
		idx++;
	}
	
	return dato;
}


int main() {
  BST miArbol;
  ifstream archivo("bitacoraOrdenada.txt");

      string mes;
      string dia;
      string hora;
      string ip, ipAnt;
      string error;
      string todo;
      string puerto;
      long key=0, keyAnt =0;
      int num=0, numAnt=0;
      bool primera = true;
      
      //complejidad O(n)
      //Recorre todo el archivo y damos 3 variables, una Key que se obtiene con la funcion ipToLong, un string de la ip normal y una de datos que contiene toda la linea como un string
      while(archivo.good()){
        getline(archivo, mes, ' ');
        getline(archivo, dia, ' ');
        getline(archivo, hora, ' ');
        getline(archivo, ip, ':');
        getline(archivo, puerto, ' ');
        getline(archivo, error, '\n');

        key=ipToKey(ip);  //5

        
        if(primera){
          keyAnt=key;
          primera=false;
        }
		
        if (key!=keyAnt && num>0){
         	miArbol.add(numAnt, keyAnt, ipAnt);
          	num=1;
          	
        }else{
          num++;
        }	
        keyAnt=key;
        numAnt=num;
        ipAnt=ip;
      }
  
      miArbol.add(numAnt, keyAnt, ipAnt);
      

    archivo.close();

    cout<<"5 IPs con más accesos:(IP-#Accesos)"<<endl;
    miArbol.print();
    cout<<endl;
  



}
