class NodeT{
	public:
		NodeT(int data, int key, string ip);
		NodeT(int data, int key, string ip, NodeT *left, NodeT *right); // No se va requerir
		int getData();
		void setData(int data, int key, string ip);
		NodeT* getLeft();
		void setLeft(NodeT *left);
		NodeT* getRight();
		void setRight(NodeT *right);
    int getKey();
    string getIp();
	private:
		int data;
    int key;
    string ip;
		NodeT *left;
		NodeT *right;	
};

NodeT::NodeT(int data, int key, string ip){

	this->data = data;
  this->key = key;
  this->ip = ip;
	this->left = nullptr;
	this->right = nullptr;
}

NodeT::NodeT(int data, int key, string ip, NodeT *left, NodeT *right){
	this->data = data;
  this->key = key;
  this->ip = ip;
	this->left = left;
	this->right = right;
}

int NodeT::getData(){
	return data;
}

int NodeT::getKey(){
  return key;
}

string NodeT::getIp(){
  return ip;
}

void NodeT::setData(int data, int key, string ip){
	this->data = data;
  this->key = key;
  this->ip = ip;
}

NodeT* NodeT::getLeft(){
	return left;
}

void NodeT::setLeft(NodeT *left){
	this->left = left;
}

NodeT* NodeT::getRight(){
	return right;
}
void NodeT::setRight(NodeT *right){
	this->right = right;
}
