#include "NodeT.h"
#include <deque>
#include <queue>

class BST{
	public:
		BST();
		~BST();
		void add(int data, int numero, string ip);
		bool search(int data);
		void ancestors(int data);
		int whatlevelamI(int data);
    	void print();
    	int i=0;
    	

	private:
		NodeT *root;
	 	void inOrdenConv(NodeT *r);
		void niveles(NodeT *r);
		void imprimir(NodeT *r);
		void destruye(NodeT *r);
		int howManyChildren(NodeT *r);
		int succ(NodeT *r);
		int pred(NodeT *r);
};

//Constructor 
BST::BST(){
	root = nullptr;
}

//destructor
BST::~BST(){
	destruye(root);
}

//elimina los datos del arbol hasta que sean NULL (elimina el arbol)
//complejidad O(n)

void BST::destruye(NodeT *r){
	if (r != nullptr){
		destruye(r->getLeft());
		destruye(r->getRight());
		delete r;
	}
}

//devuelve el sucesor
//complejidad O(n)
int BST::succ(NodeT *r){
	NodeT *curr = r->getRight();
	while (curr->getLeft() != nullptr){
		curr = curr->getLeft();
	}
	return curr->getData();
}

//devuelve el sucesor del otro lado
//complejidad O(n)
int BST::pred(NodeT *r){
	NodeT *curr = r->getLeft();
	while (curr->getRight() != nullptr){
		curr = curr->getRight();
	}
	return curr->getData();
}

//Añane datos al arbol, al ser un BST este se ordena conforme se van añadiendo
//complejidad O(n)
void BST::add(int data, int key, string ip){
	NodeT *curr = root;
	NodeT *father = nullptr;
	while (curr != nullptr){
		//if (curr->getData() == data){
		//	return;
		//}
		father = curr;
		//curr = (curr->getData() > data) ? curr->getLeft() : curr->getRight();
    
      
    
    if(curr->getData()==data){
      if(curr->getKey()>key){
        curr=curr->getLeft();
      }else{
        curr=curr->getRight();
      }
      //cout<<"fue igual"<<endl;
    }else if(curr->getData() > data){
      curr =curr->getLeft();
    }else{
      curr =curr->getRight();
    }
    
	}
	if (father == nullptr){
		root = new NodeT(data, key, ip);
	}
  
	else{
    if (father->getData()== data){
      if(father->getKey()>key){
        father->setLeft(new NodeT(data, key, ip));
      }else{
        father->setRight(new NodeT(data, key, ip));
      }
      //cout<<"fue igual"<<endl;
     
		}else if (father->getData() > data){
			father->setLeft(new NodeT(data, key, ip));
      //cout<<"no igual"<<endl;
		}
		else{
			father->setRight(new NodeT(data, key, ip));
      //cout<<"no igual"<<endl;
		}

		//father->getData() > data ? father->setLeft(new NodeT(data, key)) : 
		//						father->setRight(new NodeT(data, key));
	}

}

//Devuelve la cantidad de hijos (o hojas) que tiene el nodo
//complejidad O(1)
int BST::howManyChildren(NodeT *r){
	int cont = 0;
	if (r->getLeft() != nullptr){
		cont++;
	}
	if (r->getRight() != nullptr){
		cont++;
	}
	return cont;
}



//devuelve si existe o no un dato en el arbol
//complejidad O(n)
bool BST::search(int data){
	NodeT *curr = root;
	while (curr != nullptr){
		if (curr->getData() == data){
			return true;
		}
/*
		if (curr->getData() > data){
			curr = curr->getLeft();
		}
		else{
			curr = curr->getRight();
		}
*/
		curr = (curr->getData() > data) ? curr->getLeft() : curr->getRight();
	}
	return false;
}


//devuelve los ancestros de un cierto dato
//complejidad O(n)
void BST::ancestors(int data){
  deque<int> q;
  NodeT *curr = root;
  cout<<"Los ancestros de "<<data<<" son: ";
  int cont=0;
	while (curr != nullptr){
    
		if (curr->getData() == data){
			for(int i=0;i<cont;i++){
        cout<<q.front()<<" ";
        q.pop_front();
      }
      cout<<endl;
      return;
		}
    cont++;
    q.push_front(curr->getData());
		if (curr->getData() > data){
			curr = curr->getLeft();
		}
		else{
			curr = curr->getRight();
    }
	}
  cout<<" numero invalido"<<endl;
  
  
}


//devuelve un entero del nivel en el que se encuentra un cierto dato, si el dato no existe se devuelve -1
//complejidad O(n)
int BST::whatlevelamI(int data){
  NodeT *curr = root;
  int cont=0;
	while (curr != nullptr){
    
		if (curr->getData() == data){
			return cont;
      break;
		}
    cont++;
		if (curr->getData() > data){
			curr = curr->getLeft();
		}
		else{
			curr = curr->getRight();
    }
	}
  
  return -1;
}


//Despliega el arbol en formato de inorden converso/reverso y solo de los primeros 5
//Complejidad:O(n)
void BST::inOrdenConv(NodeT *r){
  if (r != nullptr){
    inOrdenConv(r->getRight());
    i++;
    if (i<=5){
      cout<<(r->getIp())<<"-"<<r->getData()<<endl;
    }
    inOrdenConv(r->getLeft());
  }
}




// Complejidad: O(n)
//imprime todos los ordenes y su uso es mas de edicion
void BST::print(){
  //cout<<"InOrden converso"<<":"<<endl;
  inOrdenConv(root);
  cout<<endl;
}




