/*
****Actividad 4.3****
Actividad Integral de Grafos

Nombre:  Javier Garza Pedraza          Matricula: A00828424
Nombre:  Andres Piñones Besnier        Matricula: A01570150 
Creacion: 20/11/2020
*/


#include <iostream>
#include <fstream>
#include <unordered_map> 
#include <utility>
#include <vector>

using namespace std;


//Complejidad: O(n)
//Esta funcion imprime todos los datos por cantidad de accesos en forma descendente
void descendente(vector<vector<pair<int,string>>> &listAdj, int nodos, int cantidadMaxima){
  for (int i=cantidadMaxima; i>0; i--){
      for (int j=0; j<nodos; j++){
        if (listAdj[j][0].first==i){
          cout<<"ip: "<<listAdj[j][0].second<<" cantidad: "<<listAdj[j][0].first<<endl;

        }
      }
  }
}


//Complejidad: O(n)
//Esta funcion imprime los datos con un mayor fan out
void mayor(vector<vector<pair<int,string>>> &listAdj, int nodos, int cantidadMaxima){

  cout<<"Masters(ip con mayores fan-out): "<<endl;

  for (int j=0; j<nodos; j++){
    if (listAdj[j][0].first==cantidadMaxima){
      cout<<"ip: "<<listAdj[j][0].second<<" cantidad: "<<listAdj[j][0].first<<endl;

    }
  }
}



int main() {
  unordered_map<string, pair<int, int> > umap; 


  string dato;
  string nodos, arcos;


  ifstream archivo("bitacora.txt");
  
  
  getline(archivo, nodos, ' ');
  getline(archivo, arcos, '\n');
  int nodosInt = stoi(nodos);
  int arcosInt = stoi(arcos);
  int mapInt = 0;
  string nada, ip1, ip2;
  int cantidadMaxima = 0;
  int cont = 0;

  vector<vector<pair<int,string>> > listAdj (nodosInt);

  cout<<"Nodos: "<<nodosInt<<"    "<<"Arcos: "<<arcos<<endl;

  
  //Complejidad: O(n)
  //Esta funcion trabaja con el archivo para leerlo e insertar los datos en la lista adyacente
    while(archivo.good() ){
     
      getline(archivo, dato, '\n');

      umap[dato] = (make_pair(mapInt, 0)); 

      listAdj[mapInt].push_back(make_pair(0, dato));

      mapInt++;
      if (nodosInt==mapInt){
        while(archivo.good()){
          getline(archivo, nada, ' ');
          getline(archivo, nada, ' ');
          getline(archivo, nada, ' ');
          getline(archivo, ip1, ':');
          getline(archivo, nada, ' ');
          getline(archivo, ip2, ':');
          getline(archivo, nada, '\n');


          umap[ip1].second += 1;
          
          cont++;
        
          listAdj[umap[ip1].first][0].first=umap[ip1].second;

          if (umap[ip1].second>cantidadMaxima){
            cantidadMaxima=umap[ip1].second;
          }
        }
        
        break;
      }

      
    }
 
  archivo.close();


  //cout<<"Cantidad Maxima: "<<cantidadMaxima<<endl;
  //printListAdj(listAdj);


  descendente(listAdj, nodosInt, cantidadMaxima);

  cout<<endl; 
  
  mayor(listAdj, nodosInt, cantidadMaxima);
}