/*
****Actividad 5.2****
Actividad Integral sobre el uso de códigos hash

Nombre:  Javier Garza Pedraza          Matricula: A00828424
Nombre:  Andres Piñones Besnier        Matricula: A01570150 
Creacion: 27/11/2020
*/
#include <iostream>
#include <vector>
#include <fstream>
#include <unordered_map>

using namespace std;

//Complejidad: O(n)
//Con esta funcion se muestra la cantidad de accesos y despliega los mismos con su fecha y razon de acceso
void mostrar(unordered_map<string, vector<string>> umap){
  string ip;
  cout<<"inserta una ip"<<endl;
  cin>>ip;

  cout<<"cantidad de accesos: "<<umap[ip].size()<<endl;
  for(int i = 0; i<umap[ip].size(); i++){
    cout<<umap[ip][i]<<endl;
  }

  //ejemplo para no tener que poner una ip
  /*
  cout<<"cantidad de accesos: "<<umap["199.89.192.11"].size()<<endl;
  for(int i = 0; i<umap["199.89.192.11"].size(); i++){
    cout<<umap["199.89.192.11"][i]<<endl;
  }
  */
}



int main() {
  vector<string> lista;
  unordered_map<string, vector<string>> umap; 


  ifstream archivo("bitacoraACT5_2 .txt");

  string mes, dia, hora, ip, razon, nada, linea;

  //Complejidad: O(n)
  //Esta funcion lee todo el archivo y lo almacena en un vector que se almacena en un unordenmap por ip
  while(archivo.good()){
    getline(archivo, mes, ' ');
    getline(archivo, dia, ' ');
    getline(archivo, hora, ' ');
    getline(archivo, ip, ':');
    getline(archivo, nada, ' ');
    getline(archivo, razon, '\n');

    linea="dia: " + dia+" mes: "+mes+" razon: "+razon;

    //cout<<fecha<<" "<<dia<<" "<<hora<<" "<<ip<<" "<<razon<<endl;

    if (umap.count(ip)) {
      umap.at(ip).push_back(linea);
    } else {
        umap.insert(make_pair(ip, vector<string>()));
        umap.at(ip).push_back(linea);
    }
  }
    archivo.close();

  mostrar(umap);
}