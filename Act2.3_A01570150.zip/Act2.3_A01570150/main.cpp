#include <iostream>
#include <fstream> 
#include "linkedlist.h"
using namespace std;

//complejidad O(n)
//traduce del string de ip a una key de tipo entera
long ipToLong(string ip){
	int idx = 0;
	long datoFinal= 0, dato = 0;
	while (idx < ip.size()){
		if (ip[idx]!= '.' && ip[idx]!=':'){
			dato = dato*10 + ip[idx]-'0';
		}
		else{
			datoFinal = datoFinal*1000 + dato;
			dato = 0;
		}
		idx++;
	}
	datoFinal = datoFinal*10000 + dato;
	return datoFinal;
}


struct datos{
  long key;
  string ip; 
  string caso; 
};


int main() {
  LinkedList<datos> lista {};
  ifstream archivo("bitacoraCorta.txt");

    string mes;
    string dia;
    string hora;
    string ip;
    string error;
    string todo;
    long ipLong;

    //complejidad O(n)
    //Recorre todo el archivo y damos 3 variables, una Key que se obtiene con la funcion ipToLong, un string de la ip normal y una de datos que contiene toda la linea como un string
    while(archivo.good()){
      getline(archivo, mes, ' ');
      getline(archivo, dia, ' ');
      getline(archivo, hora, ' ');
      getline(archivo, ip, ' ');
      getline(archivo, error, '\n');

      todo=mes+" "+dia+" "+hora+" "+ip+" "+error;
      ipLong=ipToLong(ip);
      datos dato;
      dato.key=ipLong;
      dato.ip=ip;
      dato.caso=todo;
      //inserta dato a la lista
      lista.addFront(dato);
      
      
    }
  archivo.close();

  

  string ip1;
  string ip2;
  string respuesta;

  
  long long ip1Long, ip2Long;

  ip1Long=ipToLong(ip1);
  ip2Long=ipToLong(ip2);

  lista.ordenar();
  lista.print();

  do{
    cout<<"rango de ip. \n  Primera ip: "<<endl;
    cin>>ip1;
    cout<<"Segunda ip"<<endl;
    cin>>ip2;

    ip1Long=ipToLong(ip1);
    ip2Long=ipToLong(ip2);


    lista.pedirDatos(ip1Long,ip2Long);
    cout<<"desea pedir mas datos o  guardar (seguir---no)";
    cin>>respuesta;
  }while(respuesta != "no");

  lista.guardarDatos();

  return 0;
}
