#include <iostream>
#include "node.h"

using namespace std;

template <class T>
class LinkedList{
  public: 
    LinkedList();
    ~LinkedList();
    void addFront(T dt);
    void removeFront();
    void print();
    void ordenar();
    int lenght();
    void pedirDatos(long ip1, long ip2);
    void guardarDatos();
  private:
    Node<T> *frente;
    Node<T> *trailer;
  
};

//complejidad O(1)
//Constructor
template <class T>
LinkedList<T>::LinkedList(){
  frente=new Node<T>;
  trailer=new Node<T>;
  frente->next=trailer;
  trailer->prev=frente;
  frente->prev=NULL;
  trailer->next=NULL;
}


//complejidad O(1)
//Esta funcion añade un dato al frente de la lista doblemente enlazada
template <class T>
void LinkedList<T>::addFront(T dt){
  Node<T> *nd=new Node<T>;
  nd->data=dt;
  nd->prev=frente;
  nd->next=frente->next;

  frente->next->prev=nd;
  frente->next=nd;
}

//complejidad O(1)
//Esta funcion elimina el dato que esta al frente de la lista
template <class T>
void LinkedList<T>::removeFront(){
  Node<T> *nd = frente->next->next;

  delete frente->next;

  frente->next=nd;
  nd->prev=frente;
}

//complejidad O(n)
//esta funcion guarda los datos que estan entre el rango de las 2 ip
template <class T> 
void LinkedList<T>::pedirDatos(long ip1, long ip2){
 
  Node<T> *nd=trailer->prev;

    while(nd!=frente){
      //cout<<nd->data.ip<<"  |  ";
      //cout<<nd->data.key<<endl;
      if (ip1<nd->data.key && ip2>nd->data.key ){
        cout<<nd->prev->data.caso<<endl;

      }
      nd=nd->prev;
    }
}

template <class T> 
void LinkedList<T>::guardarDatos(){
  ofstream myfile;
  myfile.open ("bitacoraFinal.txt", ios::out);
  Node<T> *nd=trailer->prev;

    while(nd!=frente){
      //cout<<nd->data.ip<<"  |  ";
      //cout<<nd->data.key<<endl;
        
        
      myfile<<nd->prev->data.caso<<endl;
        
      
      nd=nd->prev;
    }
  myfile.close();
}

//complejidad O(1)
//imprime la lista entrelasada en orden descendente 
template <class T>
void LinkedList<T>::print(){

  Node<T> *nd=frente->next;

    while(nd!=trailer){
      cout<<nd->data.ip<<"  |  ";
      //cout<<nd->data.key;
      cout<<endl;
      nd=nd->next;//->next;
    }
}


//complejidad O(n)
//nos regresa el tamaño de la lista
template <class T> 
int LinkedList<T>::lenght(){
  Node<T> *nd=trailer->prev;
  int i;
    while(nd!=frente->next){
      
      nd=nd->prev;
      i++;
    }
  return i;
}

//complejidad O(n^2)
//esta funcion ordena los datos de key ip con el metodo burbuja
template <class T>
void LinkedList<T>::ordenar(){
  
  Node<T> *nodo=trailer->prev;

  Node<T> *nd=trailer->prev;
  Node<T> *nd2=trailer->prev->prev;
  long aux;
  string ip;
  string loDemas;
    for(int j=0; j<=lenght(); j++){
      Node<T> *nodo=trailer->prev;

      Node<T> *nd=trailer->prev;
      Node<T> *nd2=trailer->prev->prev;
      long aux;
      string ip;
      string loDemas;
      for(int i=0; i<=lenght(); i++){
        aux=nd2->data.key;
        

        if (nd->data.key>nd2->data.key){
          
          aux=nd->data.key;
          ip=nd->data.ip;
          loDemas=nd->data.caso;

          nd->data.key=nd2->data.key;
          nd->data.ip=nd2->data.ip;
          nd->data.caso=nd2->data.caso;

          nd2->data.key=aux;
          nd2->data.ip=ip;
          nd2->data.caso=loDemas;
          
        }
        aux=nd2->data.key;
        string aux = " ";
        cout<<aux;  //***********
        nd=nd->prev;
        nd2=nd2->prev;
      }
    }
    cout<<endl;
}


//complejidad O(n)
//destructor
template <class T>
LinkedList<T>::~LinkedList(){
  while(frente->next!=trailer)
    removeFront();
  
  delete frente;
  delete trailer;
}