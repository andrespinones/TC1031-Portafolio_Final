#ifndef node_h
#define node_h

template <class T>
class Node{
  public:
    T data;
    Node<T> *prev;
    Node<T> *next;

};


#endif